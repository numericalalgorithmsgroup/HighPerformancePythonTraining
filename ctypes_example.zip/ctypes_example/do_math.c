int add2(int a)
{
  return a + 2;
}
