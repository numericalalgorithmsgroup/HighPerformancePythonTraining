#!/usr/bin/env python3

from ctypes import cdll

domath = cdll.LoadLibrary("./do_math.so")

print("add2(5): {}".format(domath.add2(5)))
